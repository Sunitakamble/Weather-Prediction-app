# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 18:51:45 2024

@author: Admin
"""

from flask import Flask, render_template, request
import pandas as pd
import numpy as np
import requests
from sklearn.linear_model import LinearRegression

app = Flask(__name__)

# Sample model for demonstration; replace with your own
model = LinearRegression()

# Sample model training data (replace with actual data and model training)
def train_model():
    # Dummy data for demonstration; replace with real data
    X = pd.DataFrame({
        'temperature': [20, 22, 24, 26, 28],
        'humidity': [30, 40, 50, 60, 70],
        'pressure': [1010, 1015, 1020, 1025, 1030]
    })
    y = pd.Series([100, 200, 300, 400, 500])
    model.fit(X, y)

train_model()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        temperature = float(request.form['temperature'])
        humidity = float(request.form['humidity'])
        pressure = float(request.form['pressure'])

        prediction = model.predict([[temperature, humidity, pressure]])[0]
        return render_template('result.html', prediction=prediction)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
